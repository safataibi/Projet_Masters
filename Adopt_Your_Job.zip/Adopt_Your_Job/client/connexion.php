<!DOCTYPE html>
<?php require '../FCT/FCT.php';
  session_start(); ?>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="../style/style.css">
    <script src="js/script.js"></script>
    <title>Adopt Your Job</title>
</head>

<body>

    
<?php topnav(); ?>


        <div class="Bandeau">
            <div class="divider"></div>

            <div class="heading">
                    <h2>Connectez-vous!</h2>
            
            <?php 
                if(isset($_GET['erreur'])){
                    echo '<h3>Un ou plusieurs champs vide(s)!</h3>';
                }
            ?>
            </div>
        </div>
<div class="container">



<div class="row">
    <div class="col-lg-10 col-lg-offset-1"> <!-- Affichage responsive du formulaire à l'aide du Grid System (Bootstrap) -->
        <form id="contact-form" method="post" action="../traitement/connect.php" autocomplete="off">

            <div class="row">

                <div class="col-md-12">
                    <label for="mail">Email </label>
                    <input id="mail" type="text" name="mail" class="form-control" placeholder="Votre Email" value="<?php if(isset($_GET['mail'])){echo $_GET['mail']; } ?>">
                    <p class="comments"><?php if(isset($_GET['mail'])){ if($_GET['mail'] == ""){echo "Ton email est entre de bonnes mains !";} } ?></p>
                </div>

                <div class="col-md-12">
                    <label for="mdp1">Mot de passe</label>
                    <input id="mdp1" type="password" name="mdp1" class="form-control" placeholder="Mot de passe" value="">
                    <p class="comments"></p>
                </div>

                <div class="col-md-12">
                    <input type="submit" class="button1" value="Se connecter">
                </div>  

            </div>
             
        </form>

        <form id="contact-form" method="post" action="../client/inscription.php" >

            <div class="row">

                <div class="col-md-12">
                    <input type="submit" class="button1" value="Pas encore inscrit ? c'est par ici !">
                </div>

            </div>
        </form>
         
     </div>
</div>

</body>
</html>