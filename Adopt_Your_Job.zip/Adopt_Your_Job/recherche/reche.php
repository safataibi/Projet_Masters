<!DOCTYPE html>
<?php require '../FCT/FCT.php';
  session_start();
  ?>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="../style/style.css">
    <script type="text/javascript"  src="../fct/JS.js"></script>
    <script type="text/javascript"  src="../fct/jquery.js"></script>
    <title>Adopt Your Job</title>
</head>


<body>


<?php topnav(); ?>


<div class="Bandeau">
            <div class="divider"></div>

            <div class="heading">
                    <h2>Portail de Recherche</h2>
            </div>
</div>

<?php
if(empty($_POST['a'])){
    echo '<meta http-equiv="refresh" content="0;url=recherche.php"';

}
if(empty($_POST['dpt']) AND empty($_POST['reg'])){
    echo '<meta http-equiv="refresh" content="0;url=recherche.php"';
}



if($_POST['a']=='dpt'){
    if($_POST['b']=='ville'){
        echo 'Selectionnez une ville: <br>';
        echo '<select name="idVille">';
        getVilles($_POST['dpt'],$_POST['a']);
        echo '</select>';
    }
}

if($_POST['a']=='reg'){
    if($_POST['b']=='ville'){
        echo 'Selectionnez une ville: <br>';
        echo '<select name="idVille">';
        getVilles($_POST['reg'],$_POST['a']);
        echo '</select>';
    }
}
?>

</body>
</html>