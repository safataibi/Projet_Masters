<!DOCTYPE html>
<?php require '../FCT/FCT.php';
  session_start();
  ?>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="../style/style.css">
    <script type="text/javascript"  src="../fct/JS.js"></script>
    <script type="text/javascript"  src="../fct/jquery.js"></script>
    <title>Adopt Your Job</title>
</head>


<body>


<?php topnav(); ?>


<div class="Bandeau">
            <div class="divider"></div>

            <div class="heading">
                    <h2>Portail de Recherche</h2>
            </div>
</div>

<?php
    if(isset($_GET['reg'])){
       getInfosVille(44);
          }
        else
        {
          echo '<div class="container">

                      <form action= "recherche.php" method="post">
                          <div class="form-grp">

                          <label for="Ou"> Où? </label>
                          <select name="a" onchange=lieu(a)>
                          <option value=""> - - - - </option>
                          <option value="reg">Régions</option>
                          <option value="dpt">Departements</option>
                          </select>

                          <select name="reg" id="reg" class="reg">';
                          echo getLieu("region");
                          echo '
                          </select>

                          <select name="dpt" id="dpt" class="dpt">';
                          echo getLieu("dpt");
                          echo '
                          </select>

                          <br>

                          <label for="Quoi?"> Quoi? </label>
                          <select name="b">
                          <option value="ville">Villes</option>
                          <option value="etab">Etablissements</option>
                          <option value="masters">Masters</option>
                          </select>
                          <br>

                          <input type="submit" name="Envoyer" value="Envoyer" />
                          </div>
                      </form>
                </div>';
        }
    if(isset($_POST['a'])){
      if(empty($_POST['dpt']) AND empty($_POST['reg'])){
          echo '<meta http-equiv="refresh" content="0;url=recherche.php"';
      }
      if($_POST['a']=='reg'){
        $domaine=$_POST['reg'];
      }
      if($_POST['a']=='dpt'){
        $domaine=$_POST['dpt'];
      }

      echo '<form action="reche.php" method="POST">';
        if($_POST['b']=='ville'){
            echo 'Selectionnez une ville: <br>';
            echo '<select name="idVille">';
            getVilles($domaine,$_POST['a']);
            echo '</select>';
        }
        if($_POST['b']=='etab'){
          echo 'Selectionnez un établissement: <br>';
          echo '<select name="idEtab">';
          getEtab($domaine,$_POST['a']);
          echo '</select>';
       }
        if($_POST['b']=='masters'){
          echo 'Selectionnez un master: <br>';
          echo '<select name="iDMaster">';
          getMasters($domaine,$_POST['a']);
          echo '</select>';
        }

      echo '<input type=submit name=Go value=GO />
            </form>';
    }


?>
</body>
</html>
