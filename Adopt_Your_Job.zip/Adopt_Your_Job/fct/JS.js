function lieu(a) {
    //console.log(a.value);
    if(a.value=='reg'){
        $('.reg').css("display","inline");
        $('.dpt').css("display","none");
        
        console.log($('.reg').val());
        console.log($('.dpt').val());

        $('#dpt').value=0;

        console.log($('.reg').val());
        console.log($('.dpt').val());
    }
    if(a.value=='dpt'){
        $('.dpt').css("display","inline");
        $('.reg').css("display","none");
        console.log($('.reg').val());
        console.log($('.dpt').val());
        $('#reg').value=0;
        console.log($('.reg').val());
        console.log($('.dpt').val());
    }
    if(a.value==""){
        $('.reg').css("display","none");
        $('.dpt').css("display","none");        
    }
}
