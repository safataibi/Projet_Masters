CREATE TABLE mytable(
   id   INTEGER  NOT NULL PRIMARY KEY 
  ,region_code VARCHAR(3) NOT NULL
  ,code VARCHAR(3) NOT NULL
  ,nom  VARCHAR(43) NOT NULL
);
INSERT INTO mytable(id,region_code,code,nom) VALUES (1,'01','Guadeloupe','guadeloupe');
INSERT INTO mytable(id,region_code,code,nom) VALUES (2,'02','Martinique','martinique');
INSERT INTO mytable(id,region_code,code,nom) VALUES (3,'03','Guyane','guyane');
INSERT INTO mytable(id,region_code,code,nom) VALUES (4,'04','La Réunion','la reunion');
INSERT INTO mytable(id,region_code,code,nom) VALUES (5,'06','Mayotte','mayotte');
INSERT INTO mytable(id,region_code,code,nom) VALUES (6,'11','Île-de-France','ile de france');
INSERT INTO mytable(id,region_code,code,nom) VALUES (7,'24','Centre-Val de Loire','centre val de loire');
INSERT INTO mytable(id,region_code,code,nom) VALUES (8,'27','Bourgogne-Franche-Comté','bourgogne franche comte');
INSERT INTO mytable(id,region_code,code,nom) VALUES (9,'28','Normandie','normandie');
INSERT INTO mytable(id,region_code,code,nom) VALUES (10,'32','Hauts-de-France','hauts de france');
INSERT INTO mytable(id,region_code,code,nom) VALUES (11,'44','Grand Est','grand est');
INSERT INTO mytable(id,region_code,code,nom) VALUES (12,'52','Pays de la Loire','pays de la loire');
INSERT INTO mytable(id,region_code,code,nom) VALUES (13,'53','Bretagne','bretagne');
INSERT INTO mytable(id,region_code,code,nom) VALUES (14,'75','Nouvelle-Aquitaine','nouvelle aquitaine');
INSERT INTO mytable(id,region_code,code,nom) VALUES (15,'76','Occitanie','occitanie');
INSERT INTO mytable(id,region_code,code,nom) VALUES (16,'84','Auvergne-Rhône-Alpes','auvergne rhone alpes');
INSERT INTO mytable(id,region_code,code,nom) VALUES (17,'93','Provence-Alpes-Côte d''Azur','provence alpes cote dazur');
INSERT INTO mytable(id,region_code,code,nom) VALUES (18,'94','Corse','corse');
INSERT INTO mytable(id,region_code,code,nom) VALUES (19,'COM','Collectivités d''Outre-Mer','collectivites doutre mer');
