<?php

require '../FCT/FCT.php';
    if(isset($_POST['nom']) AND isset($_POST['prenom']) AND isset($_POST['tel']) AND isset($_POST['age'])  AND 
    isset($_POST['mail']) AND isset($_POST['mailconf']) AND isset($_POST['mdpconf']) AND isset($_POST['mdp'])){// tests des champs vides
        
        if(test_inscr($_POST['nom'],$_POST['prenom'],$_POST['tel'],$_POST['age'],
        $_POST['mail'],$_POST['mailconf'],$_POST['mdpconf'],$_POST['mdp'])){//test des champs valides

            inscription($_POST['nom'],$_POST['prenom'],$_POST['tel'],$_POST['age'],
            $_POST['mail'],$_POST['mdp']);//entrée des champs ds la BD
            
        }
    }
    
    else{
    $erreur="Tous les champs doivent etre completés";
    echo "<meta http-equiv='refresh' content='1;url=../client/inscription.php?erreur=".$erreur."'/>";
    }


   /* 
include('../fct/FCT.php');





if($_POST['prenom'] == "" or $_POST['nom'] == "" or $_POST['mail'] == "" or $_POST['mdp1'] != $_POST['mdp2']){
    echo '<meta http-equiv="refresh" content="1; URL=../client/inscription.php?prenom='.$_POST['prenom'].'&nom='.$_POST['nom'].'&mail='.$_POST['mail'].'&num='.$_POST['num'].'">';
}
else{
    if($_POST['num'] != ""){
        envoi_inscr($_POST['prenom'],$_POST['nom'],$_POST['mail'],$_POST['num'],$_POST['mdp1']);
        echo '<meta http-equiv="refresh" content="1; URL=../client/inscription.php?ok=ok">';
    }
    else{
        envoi2_inscr($_POST['prenom'],$_POST['nom'],$_POST['mail'],$_POST['mdp1']);
        echo '<meta http-equiv="refresh" content="1; URL=../client/inscription.php?ok=ok">';
    }
}
*/
?>