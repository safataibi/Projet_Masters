<?php  
require '../FCT/FCT.php';
session_start(); 

envoiComm($_POST['comm'],$_SESSION['client']['ID'],$_SESSION['client']['Prenom'],$_POST['domaine'],$_POST['nom']);

//echo '<meta http-equiv="refresh" content="0;url=../recherche/region.php?reg='.$_POST['reg'].'"/>';
  
?>