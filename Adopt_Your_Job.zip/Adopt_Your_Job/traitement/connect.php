
      <?php
  session_start();

  include('../fct/FCT.php');
  $bdd= getBD();
  $q="select * from utilisateur
    where
    mail='".$_POST['mail']."'
    and mdp='".$_POST['mdp1']."'
    ";
  $req= $bdd->query($q);
  $c = $req->fetch();

if($c['mail']=="" || $c['mdp']=="")
{
  echo '<meta http-equiv="refresh" content="0; URL=../client/connexion.php?erreur=fail"/>';
}

else
{
  $_SESSION['client']=array(
    'ID' => $c['id_user'],
    'Nom' => $c['nom'],
    'Prenom' => $c['prenom'],
    'Mail' => $c['mail'],
    'Mot de passe' => $c['mdp']
  );

  echo '<meta http-equiv="refresh" content="0; URL=../index/index.php"/>';
}